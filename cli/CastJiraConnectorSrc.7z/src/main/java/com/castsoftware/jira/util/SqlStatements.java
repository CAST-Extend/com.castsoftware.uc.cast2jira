package com.castsoftware.jira.util;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.castsoftware.jira.pojo.ActionPlanViolation;

/**
 * The Class SqlStatements stores the sql statement used to retrieve the action
 * plan stored in the database
 * 
 * @author FME
 * @version 1.1
 */

public class SqlStatements {

	/** The log. */
	public static Log log = LogFactory.getLog(SqlStatements.class);

	/** The appname. */
	private String appname;

	/** The schema profile. */
	private String schemaProfile;

	/** The database provider. */
	private String databaseProvider;

	/** The map. */
	private HashMap<Integer, ActionPlanViolation> map = new HashMap<Integer, ActionPlanViolation>(
			0);

	/**
	 * Instantiates a new sql statements.
	 * 
	 * @param appname
	 *            the appname
	 * @param schemaProfile
	 *            the schema profile
	 * @param databaseProvider
	 *            the database provider
	 * @throws Exception
	 *             the exception
	 */
	public SqlStatements(String appname, String schemaProfile,
			String databaseProvider) throws Exception {
		setAppname(appname);
		setSchemaProfile(schemaProfile);
		setDatabaseProvider(databaseProvider);
	}

	/**
	 * Gets the action plan.
	 * 
	 * @param connection
	 *            the connection
	 * @return the action plan
	 * @throws SQLException
	 *             the SQL exception
	 */
	public HashMap<Integer, ActionPlanViolation> getActionPlan(
			Connection connection) throws SQLException {
		try {
			PreparedStatement pst = connection
					.prepareStatement(getSQLStatement());
			pst.setString(1, getAppname());

			log.debug("Sql Statement to execute to get ation plan: "
					+ getSQLStatement());
			ResultSet rs = pst.executeQuery();
			ViolationCRC crc = new ViolationCRC();
			while (rs.next()) {
				ActionPlanViolation mr = new ActionPlanViolation(
						rs.getInt("priority"),
						rs.getTimestamp("fecha").toString(), 
						rs.getString("action_message"),
						rs.getString("object_name"),
						rs.getString("metric"), 
						rs.getString("reason"), 
						rs.getString("desciption"),
						rs.getString("remediation"), 
						rs.getString("reference"), 
						rs.getString("vil_example"),
						rs.getString("rem_exampel"), 
						rs.getString("output"), 
						rs.getString("total"),
						rs.getString("source_path"),
						rs.getInt("line_start"),
						rs.getInt("line_end"),
						rs.getString("source_code"),
						rs.getString("tech_criteria"),
						rs.getString("business_criteria"),
						rs.getInt("violation_status")
						);
				try {
					crc.setHashCode(mr.getFieldsConcatenated());
					map.put(crc.getHashCode(), mr);
				} catch (Exception ex) {
					log.error("CRC code has not been calculed - Review the SqlStatemnt output because the record will not be added to Jira : "
							+ mr.getFieldsConcatenated()
							+ ". Exception:"
							+ ex.getMessage());
				}
				log.debug("Record concatenated: " + mr.getFieldsConcatenated());
			}
			rs.close();
			pst.close();

		} catch (SQLException e) {
			log.fatal("getActionPlan(): Error Getting Action Plan!"
					+ e.getMessage());
			throw e;
		}
		return map;
	}

	/**
	 * Gets the SQL statement.
	 * 
	 * @return the SQL statement
	 * @throws SQLException
	 *             the SQL exception
	 */
	private String getSQLStatement() throws SQLException 
	{
		String techCriteria = new StringBuffer()
					.append("(string_agg((")
					.append("select dmdp.metric_description from ")
					.append(getSchemaProfile()).append(".dss_metric_type_trees dmt, ")
					.append(getSchemaProfile()).append(".dss_metric_descriptions dmdp ")
					.append("where dmt.metric_id=vap.metric_id ")
					.append("AND dmdp.language = 'ENGLISH' ")
					.append("AND dmdp.description_type_id=0 ")
					.append("AND dmdp.metric_id=dmt.metric_parent_id ")
					.append("),', ') ) tech_criteria, ")
					.toString();
	
		String businessCriteria = new StringBuffer()
	            	.append("( select string_agg(dmdp.metric_description,' ,')  ")
	            	.append("from ")
					.append(getSchemaProfile()).append(".dss_metric_type_trees dmt, ")
					.append(getSchemaProfile()).append(".dss_metric_type_trees bdmt, ")
					.append(getSchemaProfile()).append(".dss_metric_descriptions dmdp ")
					.append("where dmt.metric_id=vap.metric_id ")
					.append("AND bdmt.metric_id=dmt.metric_parent_id AND dmdp.language = 'ENGLISH' AND dmdp.description_type_id=0 ")
					.append("AND dmdp.metric_id=bdmt.metric_parent_id AND dmdp.metric_id in (60011,60012,60013,60014,60016) ")
					.append(") business_criteria	")
					.toString();
		
		String statement = new StringBuffer()
			.append("SELECT vap.priority, vap.sel_date AS fecha,   vap.action_def AS action_message,  dso.object_full_name AS object_name,  ")
			.append("dvs.violation_status,  dsp.line_start,  dsp.line_end, dcs.source_path, dcs.source_code,  dmd0.metric_description AS metric, ")
			.append("dmd1.metric_description AS reason,   dmd2.metric_description AS desciption,   dmd3.metric_description AS remediation, ")
			.append("dmd4.metric_description AS reference, dmd5.metric_description AS vil_example, dmd6.metric_description AS rem_exampel,  ")
			.append("dmd7.metric_description AS output, dmd8.metric_description AS total, ")
			.append(techCriteria).append(businessCriteria)
			.append(" FROM ")
			.append("version737_central.csv_portf_tree cpt, ")
			.append("  version737_central.dss_violation_statuses dvs,  ")
			.append("  version737_central.viewer_action_plans vap, ") 
			.append("  version737_central.dss_objects dso,  ")
			.append("  version737_central.dss_translation_table dtt, ") 
			.append("  version737_local.dss_source_positions dsp, ") 
			.append("  version737_local.dss_code_sources dcs, ")
			.append("  version737_central.dss_metric_descriptions dmd0,  ")
			.append("  version737_central.dss_metric_descriptions dmd1,  ")
			.append("  version737_central.dss_metric_descriptions dmd2,  ")
			.append("  version737_central.dss_metric_descriptions dmd3,  ")
			.append("  version737_central.dss_metric_descriptions dmd4,  ")
			.append(" version737_central.dss_metric_descriptions dmd5,  ")
			.append("   version737_central.dss_metric_descriptions dmd6, ") 
			.append("   version737_central.dss_metric_descriptions dmd7, ") 
			.append("   version737_central.dss_metric_descriptions dmd8 ")
			.append(" WHERE ")
			.append("   dvs.snapshot_id = cpt.snapshot_id AND ")
			.append(" dvs.object_id = vap.object_id AND ")
			.append(" dvs.diag_id = vap.metric_id AND ")
			.append(" dso.object_id = vap.object_id AND ")
			.append(" dtt.object_id = vap.object_id AND ")
			.append(" dtt.site_object_id = dsp.object_id AND ")
			.append(" dsp.source_id = dcs.source_id AND ")
			.append(" cpt.snapshot_id = (select max(snapshot_id) from version737_central.csv_portf_tree) AND ")
			.append(" vap.metric_id = dmd0.metric_id AND ")
			.append(" dmd0.language = dmd1.language AND ")
			.append(" dmd0.metric_id = dmd2.metric_id AND ")
			.append("  dmd0.language = dmd2.language AND ")
			.append(" dmd0.metric_id = dmd3.metric_id AND ")
			.append(" dmd0.language = dmd3.language AND ")
			.append(" dmd0.metric_id = dmd4.metric_id AND ")
			.append(" dmd0.language = dmd4.language AND ")
			.append(" dmd0.metric_id = dmd5.metric_id AND ")
			.append(" dmd0.metric_id = dmd6.metric_id AND ")
			.append(" dmd0.metric_id = dmd7.metric_id AND ")
			.append(" dmd0.metric_id = dmd8.metric_id AND ")
			.append(" dmd0.language = dmd5.language AND ")
			.append(" dmd0.language = dmd6.language AND ")
			.append(" dmd0.language = dmd7.language AND ")
			.append(" dmd0.language = dmd8.language AND ")
			.append(" dmd1.metric_id = dmd0.metric_id AND ")
			.append(" dmd0.language = 'ENGLISH' AND ") 
			.append(" dmd0.description_type_id = 0 AND ") 
			.append(" dmd1.description_type_id = 1 AND ") 
			.append(" dmd2.description_type_id = 2 AND ") 
			.append(" dmd3.description_type_id = 3 AND ") 
			.append(" dmd4.description_type_id = 4 AND ") 
			.append(" dmd5.description_type_id = 5 AND ")
			.append(" dmd6.description_type_id = 6 AND ") 
			.append(" dmd7.description_type_id = 7 AND ") 
			.append(" dmd8.description_type_id = 8 AND ")   
			.append(" cpt.APP_NAME = ? ")
			.append(" GROUP BY ")
			.append("vap.metric_id, priority, fecha, action_message, dso.OBJECT_FULL_NAME,metric, reason,")
			.append("desciption,remediation, reference, vil_example, rem_exampel, output, ")
			.append("total,source_path,dsp.line_start,dsp.line_end,dtt.site_object_id, violation_status, source_code")			
			.toString();

			//		String statement = new StringBuffer()
//			.append("SELECT vap.PRIORITY priority, ")
//			.append("vap.SEL_DATE fecha, vap.ACTION_DEF action_message, " )
//			.append( "dtt.SITE_OBJECT_ID local_object_id, ")
//			.append("dtt.SITE_OBJECT_ID local_object_id, " )
//			.append("dtt.SITE_OBJECT_ID local_object_id, ")
//			.append("dso.OBJECT_FULL_NAME object_name, ")
//			.append("t0.METRIC_DESCRIPTION metric, ")
//			.append("t1.METRIC_DESCRIPTION reason, ")
//			.append("t2.METRIC_DESCRIPTION desciption, ")
//			.append("t3.METRIC_DESCRIPTION remediation, ")
//			.append("t4.METRIC_DESCRIPTION reference, ")
//			.append("t5.METRIC_DESCRIPTION vil_example, ")
//			.append("t6.METRIC_DESCRIPTION rem_exampel, ")
//			.append("t7.METRIC_DESCRIPTION output, ")
//			.append("t8.METRIC_DESCRIPTION total, ")
//			.append("dcs.source_path,")
//			.append("dsp.line_start, ")
//			.append("dsp.line_end, ")
//			.append(techCriteria).append(businessCriteria)
//			.append(" FROM ")
//			.append(getSchemaProfile()).append(".viewer_action_plans vap, ")
//			.append(getSchemaProfile()).append(".dss_objects dso, ")
//			.append(getSchemaProfile()).append(".csv_diagdetails cdd, ")
//			.append(getSchemaProfile()).append(".dss_translation_table dtt, ")
//			.append(getSchemaProfile()).append(".csv_portf_tree cpt, ")
//			.append(getLocalDatabase()).append(".dss_source_positions dsp, ")
//			.append(getLocalDatabase()).append(".dss_code_sources dcs, ")
//			.append("(((((((((SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 0) t0 ")
//			.append("LEFT OUTER JOIN ")
//			.append("(SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 1) t1 ")
//			.append("ON (t0.metric_id = t1.metric_id))")
//			.append("LEFT OUTER JOIN ")
//			.append("(SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 2) t2 ")
//			.append("ON (t0.metric_id = t2.metric_id))")
//			.append("LEFT OUTER JOIN ")
//			.append("(SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 3) t3 ")
//			.append("ON (t0.metric_id = t3.metric_id)) ")
//			.append("LEFT OUTER JOIN ")
//			.append("(SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 4) t4 ")
//			.append("ON (t0.metric_id = t4.metric_id)) ")
//			.append("LEFT OUTER JOIN ")
//			.append("(SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 5) t5 ")
//			.append("ON (t0.metric_id = t5.metric_id)) ")
//			.append("LEFT OUTER JOIN ")
//			.append("(SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 6) t6 ")
//			.append("ON (t0.metric_id = t6.metric_id)) ")
//			.append("LEFT OUTER JOIN ")
//			.append("(SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 7) t7 ")
//			.append("ON (t0.metric_id = t7.metric_id)) ")
//			.append("LEFT OUTER JOIN ")
//			.append("(SELECT metric_id, metric_description FROM ")
//			.append(getSchemaProfile()).append(".dss_metric_descriptions nm WHERE nm.language = 'ENGLISH' ")
//			.append("AND nm.description_type_id = 8) t8 ")
//			.append("ON (t0.metric_id = t8.metric_id)) ")
//			.append("WHERE vap.metric_id = t1.metric_id ")
//			.append("AND vap.object_id = dso.object_id ")
//			.append("AND vap.metric_id = cdd.diag_id ")
//			.append("AND dso.object_id = dtt.object_id ")
//			.append("AND vap.object_id = cdd.object_id ")
//			.append("AND cdd.context_id = cpt.module_id ")
//			.append("AND dsp.object_id = dtt.SITE_OBJECT_ID ")
//			.append("AND dcs.source_id = dsp.source_id ")
//			.append("AND cpt.APP_NAME = ? ")
//			.append("GROUP BY vap.metric_id, priority, fecha, action_message, dso.OBJECT_FULL_NAME,metric, reason,desciption,remediation, reference, vil_example, rem_exampel, output, total,source_path,dsp.line_start,dsp.line_end,dtt.site_object_id ")
//			.toString();
					  
		return statement;

	}

	/**
	 * Gets the appname.
	 * 
	 * @return the appname
	 */
	public String getAppname() {
		return appname;
	}

	/**
	 * Sets the appname.
	 * 
	 * @param appname
	 *            the appname to set
	 */
	public void setAppname(String appname) {
		this.appname = appname;
	}

	/**
	 * Gets the schema profile.
	 * 
	 * @return the schemaProfile
	 */
	public String getSchemaProfile() {
		return schemaProfile;
	}
	/**
	 * Gets the local database.
	 * 
	 * @return the schemaProfile
	 */
	public String getLocalDatabase() {
		return schemaProfile.replace("central", "local");
	}

	/**
	 * Sets the schema profile.
	 * 
	 * @param schemaProfile
	 *            the schemaProfile to set
	 */
	public void setSchemaProfile(String schemaProfile) {
		this.schemaProfile = schemaProfile;
	}

	/**
	 * Gets the database provider.
	 * 
	 * @return the databaseProvider
	 */
	public String getDatabaseProvider() {
		return databaseProvider;
	}

	/**
	 * Sets the database provider.
	 * 
	 * @param databaseProvider
	 *            the databaseProvider to set
	 */
	public void setDatabaseProvider(String databaseProvider) {
		this.databaseProvider = databaseProvider;
	}

}
